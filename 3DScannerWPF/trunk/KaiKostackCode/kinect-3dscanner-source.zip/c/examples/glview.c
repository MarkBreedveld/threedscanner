#include <stdio.h>
#include <string.h>
#include <stdint.h>
#include <stdlib.h>
#include "libfreenect.h"
#include <pthread.h>
#include <time.h>

#if defined(WIN32)
#include <windows.h>
#include <usb.h>
#else


#endif

#include <math.h>

// COMMENT THIS LINE OUT FOR SIMPLE NON-PTHREAD/GLUT TRANSFER TEST
#define PTHREAD_AND_GLUT

#ifdef PTHREAD_AND_GLUT

#if defined(__APPLE__)
#include <GLUT/glut.h>
#include <OpenGL/gl.h>
#include <OpenGL/glu.h>
#else
#if defined(WIN32)
#include <glut.h>
#else
#include <glut.h>
#endif
#include <GL/gl.h>
#include <GL/glu.h>
#endif

pthread_t gl_thread;
volatile int die = 0;

int g_argc;
char **g_argv;

int window;

pthread_mutex_t gl_backbuf_mutex = PTHREAD_MUTEX_INITIALIZER;

uint8_t gl_depth_front[640*480*4];
uint8_t gl_depth_back[640*480*4];

uint8_t gl_rgb_front[640*480*4];
uint8_t gl_rgb_back[640*480*4];

GLuint gl_depth_tex;
GLuint gl_rgb_tex;


pthread_cond_t gl_frame_cond = PTHREAD_COND_INITIALIZER;
int got_frames = 0;

// Kai's code

#include <windows.h>

unsigned char chKey;
int isnan(double x) { return x != x; }
int isinf(double x) { return !isnan(x) && isnan(x - x); }



void DrawGLScene()
{
	static int fcnt = 0;
	pthread_mutex_lock(&gl_backbuf_mutex);

	while (got_frames < 2) {
		pthread_cond_wait(&gl_frame_cond, &gl_backbuf_mutex);
	}

	memcpy(gl_depth_front, gl_depth_back, sizeof(gl_depth_back));
	memcpy(gl_rgb_front, gl_rgb_back, sizeof(gl_rgb_back));
	got_frames = 0;
	pthread_mutex_unlock(&gl_backbuf_mutex);

	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	glLoadIdentity();

	glEnable(GL_TEXTURE_2D);

	glBindTexture(GL_TEXTURE_2D, gl_depth_tex);
	glTexImage2D(GL_TEXTURE_2D, 0, 3, 640, 480, 0, GL_RGB, GL_UNSIGNED_BYTE, gl_depth_front);

	glBegin(GL_TRIANGLE_FAN);
	glColor4f(255.0f, 255.0f, 255.0f, 255.0f);
	glTexCoord2f(0, 0); glVertex3f(0,0,0);
	glTexCoord2f(1, 0); glVertex3f(640,0,0);
	glTexCoord2f(1, 1); glVertex3f(640,480,0);
	glTexCoord2f(0, 1); glVertex3f(0,480,0);
	glEnd();

	glBindTexture(GL_TEXTURE_2D, gl_rgb_tex);
	glTexImage2D(GL_TEXTURE_2D, 0, 3, 640, 480, 0, GL_RGB, GL_UNSIGNED_BYTE, gl_rgb_front);

	glBegin(GL_TRIANGLE_FAN);
	glColor4f(255.0f, 255.0f, 255.0f, 255.0f);
	glTexCoord2f(0, 0); glVertex3f(640,0,0);
	glTexCoord2f(1, 0); glVertex3f(1280,0,0);
	glTexCoord2f(1, 1); glVertex3f(1280,480,0);
	glTexCoord2f(0, 1); glVertex3f(640,480,0);
	glEnd();

	glutSwapBuffers();
}

void keyPressed(unsigned char key, int x, int y)
{
	chKey = key;
	if (key == 27) {
		die = 1;
		glutDestroyWindow(window);
		pthread_exit(NULL);
	}
}

void ReSizeGLScene(int Width, int Height)
{
	glViewport(0,0,Width,Height);
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	glOrtho (0, 1280, 480, 0, -1.0f, 1.0f);
	glMatrixMode(GL_MODELVIEW);
}

void InitGL(int Width, int Height)
{
	glClearColor(0.0f, 0.0f, 0.0f, 0.0f);
	glClearDepth(1.0);
	glDepthFunc(GL_LESS);
	glDisable(GL_DEPTH_TEST);
	glEnable(GL_BLEND);
	glBlendFunc (GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
	glShadeModel(GL_SMOOTH);
	glGenTextures(1, &gl_depth_tex);
	glBindTexture(GL_TEXTURE_2D, gl_depth_tex);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	glGenTextures(1, &gl_rgb_tex);
	glBindTexture(GL_TEXTURE_2D, gl_rgb_tex);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	ReSizeGLScene(Width, Height);
}

void *gl_threadfunc(void *arg)
{
	//printf("GL thread\n");

	glutInit(&g_argc, g_argv);

		glutInitDisplayMode(GLUT_RGB | GLUT_DOUBLE | GLUT_DEPTH | GLUT_ALPHA );
	glutInitWindowSize(1280, 480);
	glutInitWindowPosition(0, 0);

	window = glutCreateWindow("LibFreenect");

	//printf("window created!\n");

	glutDisplayFunc(&DrawGLScene);
	glutIdleFunc(&DrawGLScene);
	glutReshapeFunc(&ReSizeGLScene);
	glutKeyboardFunc(&keyPressed);

	InitGL(1280, 480);

	glutMainLoop();

		//printf("here!\n");

	pthread_exit(NULL);
	return NULL;
}

uint16_t t_gamma[2048];


// Blender Code Start

#if defined(_WIN32)
#define M_PI 3.14159265358979323846
#endif

float saasin(float fac)
{
	if(fac<= -1.0f) return (float)-M_PI/2.0f;
	else if(fac>=1.0f) return (float)M_PI/2.0f;
	else return (float)asin(fac);
}

float saacos(float fac)
{
	if(fac<= -1.0f) return (float)M_PI;
	else if(fac>=1.0f) return 0.0;
	else return (float)acos(fac);
}

float len_v3(const float a[3])
{
	return sqrtf(dot_v3v3(a, a));
}

void zero_v3(float r[3])
{
	r[0]= 0.0f;
	r[1]= 0.0f;
	r[2]= 0.0f;
}

void sub_v3_v3v3(float r[3], const float a[3], const float b[3])
{
	r[0]= a[0] - b[0];
	r[1]= a[1] - b[1];
	r[2]= a[2] - b[2];
}

void mul_v3_v3fl(float r[3], const float a[3], float f)
{
	r[0]= a[0]*f;
	r[1]= a[1]*f;
	r[2]= a[2]*f;
}

float len_v3v3(const float a[3], const float b[3])
{
	float d[3];

	sub_v3_v3v3(d, b, a);
	return len_v3(d);
}

float dot_v3v3(const float a[3], const float b[3])
{
	return a[0]*b[0] + a[1]*b[1] + a[2]*b[2];
}

float angle_normalized_v3v3(const float v1[3], const float v2[3])
{
	/* this is the same as acos(dot_v3v3(v1, v2)), but more accurate */
	if (dot_v3v3(v1, v2) < 0.0f) {
		float vec[3];
		
		vec[0]= -v2[0];
		vec[1]= -v2[1];
		vec[2]= -v2[2];
		
		return (float)M_PI - 2.0f*(float)saasin(len_v3v3(vec, v1)/2.0f);
	}
	else
		return 2.0f*(float)saasin(len_v3v3(v2, v1)/2.0f);
}

float normalize_v3_v3(float r[3], const float a[3])
{
	float d= dot_v3v3(a, a);

	/* a larger value causes normalize errors in a
	   scaled down models with camera xtreme close */
	if(d > 1.0e-35f) {
		d= sqrtf(d);
		mul_v3_v3fl(r, a, 1.0f/d);
	}
	else {
		zero_v3(r);
		d= 0.0f;
	}

	return d;
}

float normalize_v3(float n[3])
{
	return normalize_v3_v3(n, n);
}

/* Return the angle in radians between vecs 1-2 and 2-3 in radians
   If v1 is a shoulder, v2 is the elbow and v3 is the hand,
   this would return the angle at the elbow */
float angle_v3v3v3(const float v1[3], const float v2[3], const float v3[3])
{
	float vec1[3], vec2[3];

	sub_v3_v3v3(vec1, v2, v1);
	sub_v3_v3v3(vec2, v2, v3);
	normalize_v3(vec1);
	normalize_v3(vec2);

//	return angle_normalized_v3v3(vec1, vec2);	seems not to work correctly, using code from the older VecAngle3 function instead
	return saacos(vec1[0]*vec2[0] + vec1[1]*vec2[1] + vec1[2]*vec2[2]);
}

// Blender Code End


// Kai's code

#define PI 3.141592653589793
#define PI2 PI/2
#define PI3 PI/3
#define PI4 PI/4

unsigned char rgb[640*480*3];
float depth[640*480];
int depthKill[640*480];
int vertIdx[640*480];
float vertex[640*480*3];

int depthPos, up, down, mCounter;
int qScanWithMotor = 0;
int qSaveNow = 0;
int qRGBcalibration = 0;
int qRGBcalibrationLevel = 0;
int qDepthClipping = 0;
int RGBshiftX[3] ={0,0,0}, RGBshiftY[3] ={0,0,0};
float RGBshiftS[3] ={1,1,1};

time_t timerSec, timerSecOld;
int timerInc=0;
time_t scanWithMotorSec, scanWithMotorSecOld;
int scanWithMotorInc=0, scanWithMotorSampleInc=0;

short qUseTimer = 0;
short qUseMotor = 0;
int MotorTilt = 255;

int maxSteps = 5;			// maximum steps allowed until separation of structures, in depth as well as from left to right (good for filling gaps)
int samples = 5;			// count of subsamples to interpolate depth (1 = off)
int scanWithMotorSamples = 3;
int timeToWait = 1;			// time to wait for periodic scanning in seconds
int scanWithMotorTimeToWait = 2;	// time to wait between motor steps for motor scanning mode in seconds
int clippingFar = 900;
int clippingClose = 600;

void saveIniSettings(char *argv0)
{
	char *txt[80], *fileName[256] = {'\0'};
	
	strncpy(fileName, argv0, strlen(argv0) -4);
	strcat(fileName, ".ini");
	
	//printf("Saving INI File:\n%s\n", fileName);
	
	itoa(maxSteps, txt, 10);
	WritePrivateProfileString("settings", "maxSteps", txt, fileName); 
	itoa(samples, txt, 10);
	WritePrivateProfileString("settings", "samples", txt, fileName); 
	itoa(scanWithMotorSamples, txt, 10);
	WritePrivateProfileString("settings", "scanWithMotorSamples", txt, fileName); 
	itoa(timeToWait, txt, 10);
	WritePrivateProfileString("settings", "timeToWait", txt, fileName); 
	itoa(scanWithMotorTimeToWait, txt, 10);
	WritePrivateProfileString("settings", "scanWithMotorTimeToWait", txt, fileName); 
	itoa(RGBshiftX[0], txt, 10);
	WritePrivateProfileString("settings", "RGBshiftX[0]", txt, fileName); 
	itoa(RGBshiftY[0], txt, 10);
	WritePrivateProfileString("settings", "RGBshiftY[0]", txt, fileName); 
	sprintf(txt, "%g", RGBshiftS[0]);
	WritePrivateProfileString("settings", "RGBshiftS[0]", txt, fileName); 
	itoa(RGBshiftX[1], txt, 10);
	WritePrivateProfileString("settings", "RGBshiftX[1]", txt, fileName); 
	itoa(RGBshiftY[1], txt, 10);
	WritePrivateProfileString("settings", "RGBshiftY[1]", txt, fileName); 
	sprintf(txt, "%g", RGBshiftS[1]);
	WritePrivateProfileString("settings", "RGBshiftS[1]", txt, fileName); 
	itoa(RGBshiftX[2], txt, 10);
	WritePrivateProfileString("settings", "RGBshiftX[2]", txt, fileName); 
	itoa(RGBshiftY[2], txt, 10);
	WritePrivateProfileString("settings", "RGBshiftY[2]", txt, fileName); 
	sprintf(txt, "%g", RGBshiftS[2]);
	WritePrivateProfileString("settings", "RGBshiftS[2]", txt, fileName);
	itoa(clippingFar, txt, 10);
	WritePrivateProfileString("settings", "clippingFar", txt, fileName); 
	itoa(clippingClose, txt, 10);
	WritePrivateProfileString("settings", "clippingClose", txt, fileName); 
}

void loadIniSettings(char *argv0)
{
	DWORD destSize=80; 
	FILE *file;
	char *txt[80], *fileName[256] = {'\0'};
	
	strncpy(fileName, argv0, strlen(argv0) -4);
	strcat(fileName, ".ini");

	if (file = fopen(fileName, "r"))
    {
        fclose(file);
		printf("Loading INI File:\n%s\n", fileName);
		
		GetPrivateProfileString("settings", "maxSteps", "1", txt, destSize, fileName);
		maxSteps = atoi(txt);
		GetPrivateProfileString("settings", "samples", "1", txt, destSize, fileName);
		samples = atoi(txt);
		GetPrivateProfileString("settings", "scanWithMotorSamples", "1", txt, destSize, fileName);
		scanWithMotorSamples = atoi(txt);
		GetPrivateProfileString("settings", "timeToWait", "1", txt, destSize, fileName);
		timeToWait = atoi(txt);
		GetPrivateProfileString("settings", "scanWithMotorTimeToWait", "1", txt, destSize, fileName);
		scanWithMotorTimeToWait = atoi(txt);
		GetPrivateProfileString("settings", "RGBshiftX[0]", "0", txt, destSize, fileName);
		RGBshiftX[0] = atoi(txt);
		GetPrivateProfileString("settings", "RGBshiftY[0]", "0", txt, destSize, fileName);
		RGBshiftY[0] = atoi(txt);
		GetPrivateProfileString("settings", "RGBshiftS[0]", "1", txt, destSize, fileName);
		RGBshiftS[0] = atof(txt);
		GetPrivateProfileString("settings", "RGBshiftX[1]", "0", txt, destSize, fileName);
		RGBshiftX[1] = atoi(txt);
		GetPrivateProfileString("settings", "RGBshiftY[1]", "0", txt, destSize, fileName);
		RGBshiftY[1] = atoi(txt);
		GetPrivateProfileString("settings", "RGBshiftS[1]", "1", txt, destSize, fileName);
		RGBshiftS[1] = atof(txt);
		GetPrivateProfileString("settings", "RGBshiftX[2]", "0", txt, destSize, fileName);
		RGBshiftX[2] = atoi(txt);
		GetPrivateProfileString("settings", "RGBshiftY[2]", "0", txt, destSize, fileName);
		RGBshiftY[2] = atoi(txt);
		GetPrivateProfileString("settings", "RGBshiftS[2]", "1", txt, destSize, fileName);
		RGBshiftS[2] = atof(txt);
		GetPrivateProfileString("settings", "clippingFar", "1", txt, destSize, fileName);
		clippingFar = atoi(txt);
		GetPrivateProfileString("settings", "clippingClose", "1", txt, destSize, fileName);
		clippingClose = atoi(txt);
		printf("maxSteps = %d\n", maxSteps);
		printf("samples = %d\n", samples);
		printf("scanWithMotorSamples = %d\n", scanWithMotorSamples);
		printf("timeToWait = %d\n", timeToWait);
		printf("scanWithMotorTimeToWait = %d\n", scanWithMotorTimeToWait);
		printf("RGBshiftX[0] = %d\n", RGBshiftX[0]);
		printf("RGBshiftY[0] = %d\n", RGBshiftY[0]);
		printf("RGBshiftS[0] = %g\n", RGBshiftS[0]);
		printf("RGBshiftX[1] = %d\n", RGBshiftX[1]);
		printf("RGBshiftY[1] = %d\n", RGBshiftY[1]);
		printf("RGBshiftS[1] = %g\n", RGBshiftS[1]);
		printf("RGBshiftX[2] = %d\n", RGBshiftX[2]);
		printf("RGBshiftY[2] = %d\n", RGBshiftY[2]);
		printf("RGBshiftS[2] = %g\n", RGBshiftS[2]);
	}
	else saveIniSettings(argv0);
}

void filterVertices(float factor, int iterations, float surfacePreserve, short radius, short shape, short fallOff)
{
	// surfacePreserve: structure aware filter (0:surface preserve disabled, otherwise below that value edge angles define how strong the filter is applied, above it it's disabled)
	// shape: filter shape, can help smoothing axis oriented edges (0:cross, 1:horizontally, 2:vertically)
	// radius: distance count as number of edges in each direction
	// fallOff: type of smoothing fall-off (0:constant, 1:linear, 2:quadric, 3:ease/soft)
	int i,j,k,m,n,x,y,iter, connections;
	float xf, yf, zf, f, f1, f2, f3;
	float dpC, dp, surfPres;
	int idxC, idx, xEnd, yEnd;
	float vC[3],vL[3],vR[3],vU[3],vD[3],vLr[3],vRr[3],vUr[3],vDr[3];
	
	float vertexBuf[640*480*3];

	surfPres = surfacePreserve;
						
	for (iter=0; iter<iterations; iter++) {
		for (i=0; i<640*480*3; i++)
			vertexBuf[i] = vertex[i];

		if (shape != 2) yEnd = 479; else yEnd = 479-radius;
		for (y=1+radius; y<yEnd; y++) {
			if (shape != 1) xEnd = 639; else xEnd = 639-radius;
			for (x=1+radius; x<xEnd; x++) {
				idxC = y*640+x; dpC = depth[idxC]; idxC *= 3;	// center
				vC[0] = vertexBuf[idxC+0]; vC[1] = vertexBuf[idxC+1]; vC[2] = vertexBuf[idxC+2];
						
				if (dpC>340 && dpC<1081) {
					connections = 0;
					xf = 0; yf = 0; zf = 0;
					if (shape == 0) {	// cross shape
						// next vertices
						idx = (y-1)*640+x; dp = depth[idx]; idx *= 3;	// up
						if (dp>340 && dp<1081 && dp>dpC-maxSteps && dp<dpC+maxSteps) {
							vU[0] = vertexBuf[idx+0]; vU[1] = vertexBuf[idx+1]; vU[2] = vertexBuf[idx+2];
							xf += vU[0]; yf += vU[1]; zf += vU[2];
							connections++;
						}		
						idx = (y+1)*640+x; dp = depth[idx]; idx *= 3;	// down
						if (dp>340 && dp<1081 && dp>dpC-maxSteps && dp<dpC+maxSteps) {
							vD[0] = vertexBuf[idx+0]; vD[1] = vertexBuf[idx+1]; vD[2] = vertexBuf[idx+2];
							xf += vD[0]; yf += vD[1]; zf += vD[2];
							connections++;
						}
						idx = y*640+x-1; dp = depth[idx]; idx *= 3;		// left
						if (dp>340 && dp<1081 && dp>dpC-maxSteps && dp<dpC+maxSteps) {
							vL[0] = vertexBuf[idx+0]; vL[1] = vertexBuf[idx+1]; vL[2] = vertexBuf[idx+2];
							xf += vL[0]; yf += vL[1]; zf += vL[2];
							connections++;
						}
						idx = y*640+x+1; dp = depth[idx]; idx *= 3;		// right
						if (dp>340 && dp<1081 && dp>dpC-maxSteps && dp<dpC+maxSteps) {
							vR[0] = vertexBuf[idx+0]; vR[1] = vertexBuf[idx+1]; vR[2] = vertexBuf[idx+2];
							xf += vR[0]; yf += vR[1]; zf += vR[2];
							connections++;
						}
						// radius vertices
						if (surfPres > 0 || radius > 0) {
							idx = (y-radius)*640+x; dp = depth[idx]; idx *= 3;	// up
							if (dp>340 && dp<1081 && dp>dpC-maxSteps && dp<dpC+maxSteps) {
								vUr[0] = vertexBuf[idx+0]; vUr[1] = vertexBuf[idx+1]; vUr[2] = vertexBuf[idx+2];
							}		
							idx = (y+radius)*640+x; dp = depth[idx]; idx *= 3;	// down
							if (dp>340 && dp<1081 && dp>dpC-maxSteps && dp<dpC+maxSteps) {
								vDr[0] = vertexBuf[idx+0]; vDr[1] = vertexBuf[idx+1]; vDr[2] = vertexBuf[idx+2];
							}
							idx = y*640+x-radius; dp = depth[idx]; idx *= 3;		// left
							if (dp>340 && dp<1081 && dp>dpC-maxSteps && dp<dpC+maxSteps) {
								vLr[0] = vertexBuf[idx+0]; vLr[1] = vertexBuf[idx+1]; vLr[2] = vertexBuf[idx+2];
							}
							idx = y*640+x+radius; dp = depth[idx]; idx *= 3;		// right
							if (dp>340 && dp<1081 && dp>dpC-maxSteps && dp<dpC+maxSteps) {
								vRr[0] =  vertexBuf[idx+0]; vRr[1] = vertexBuf[idx+1]; vRr[2] = vertexBuf[idx+2];
							}
						}
					}
					else if (shape == 1) {	// horizontal shape
						// next vertices
						idx = y*640+x-1; dp = depth[idx]; idx *= 3;		// left
						if (dp>340 && dp<1081 && dp>dpC-maxSteps && dp<dpC+maxSteps) {
							vL[0] = vertexBuf[idx+0]; vL[1] = vertexBuf[idx+1]; vL[2] = vertexBuf[idx+2];
							xf += vL[0]; yf += vL[1]; zf += vL[2];
							connections++;
						}
						idx = y*640+x+1; dp = depth[idx]; idx *= 3;		// right
						if (dp>340 && dp<1081 && dp>dpC-maxSteps && dp<dpC+maxSteps) {
							vR[0] = vertexBuf[idx+0]; vR[1] = vertexBuf[idx+1]; vR[2] = vertexBuf[idx+2];
							xf += vR[0]; yf += vR[1]; zf += vR[2];
							connections++;
						}
						// radius vertices
						if (surfPres > 0 || radius > 0) {
							idx = y*640+x-radius; dp = depth[idx]; idx *= 3;		// left
							if (dp>340 && dp<1081 && dp>dpC-maxSteps && dp<dpC+maxSteps) {
								vLr[0] = vertexBuf[idx+0]; vLr[1] = vertexBuf[idx+1]; vLr[2] = vertexBuf[idx+2];
							}
							idx = y*640+x+radius; dp = depth[idx]; idx *= 3;		// right
							if (dp>340 && dp<1081 && dp>dpC-maxSteps && dp<dpC+maxSteps) {
								vRr[0] = vertexBuf[idx+0]; vRr[1] = vertexBuf[idx+1]; vRr[2] = vertexBuf[idx+2];
							}
						}
					}
					else if (shape == 2) {	// vertical shape
						// next vertices
						idx = (y-1)*640+x; dp = depth[idx]; idx *= 3;	// up
						if (dp>340 && dp<1081 && dp>dpC-maxSteps && dp<dpC+maxSteps) {
							vU[0] = vertexBuf[idx+0]; vU[1] = vertexBuf[idx+1]; vU[2] = vertexBuf[idx+2];
							xf += vU[0]; yf += vU[1]; zf += vU[2];
							connections++;
						}		
						idx = (y+1)*640+x; dp = depth[idx]; idx *= 3;	// down
						if (dp>340 && dp<1081 && dp>dpC-maxSteps && dp<dpC+maxSteps) {
							vD[0] = vertexBuf[idx+0]; vD[1] = vertexBuf[idx+1]; vD[2] = vertexBuf[idx+2];
							xf += vD[0]; yf += vD[1]; zf += vD[2];
							connections++;
						}
						// radius vertices
						if (surfPres > 0 || radius > 0) {
							idx = (y-radius)*640+x; dp = depth[idx]; idx *= 3;	// up
							if (dp>340 && dp<1081 && dp>dpC-maxSteps && dp<dpC+maxSteps) {
								vUr[0] =  vertexBuf[idx+0]; vUr[1] = vertexBuf[idx+1]; vUr[2] = vertexBuf[idx+2];
							}		
							idx = (y+radius)*640+x; dp = depth[idx]; idx *= 3;	// down
							if (dp>340 && dp<1081 && dp>dpC-maxSteps && dp<dpC+maxSteps) {
								vDr[0] =  vertexBuf[idx+0]; vDr[1] = vertexBuf[idx+1]; vDr[2] = vertexBuf[idx+2];
							}
						}
					}

					if (connections >= 2) {
						xf /= connections; yf /= connections; zf /= connections;	// avarage vertex absolute location from surrounding vertices
						xf -= vC[0]; yf -= vC[1]; zf -= vC[2];	// delta location relative to old center vertex
						if (surfPres == 0) {		// regular linear filter method
							//printf("%d %d | %g %g = %g\n", x,y, xf, factor, xf*factor);
							vertex[idxC+0] += xf *factor; vertex[idxC+1] += yf *factor; vertex[idxC+2] += zf *factor; // apply factor and set new center vertex
						}
						if (surfPres > 0) {	// small differences leading to strong filter strength, big differences to smaller filter strength
							f = 0;
							if (radius == 0) {
								if (shape != 1) f += PI-angle_v3v3v3(vU, vC, vD);	// calculate angle between up and down vectors
								if (shape != 2) f += PI-angle_v3v3v3(vL, vC, vR);	// calculate angle between left and right vectors and add it to f
							} else {
								if (shape != 1) f += PI-angle_v3v3v3(vUr, vC, vDr);	// calculate angle between up and down vectors
								if (shape != 2) f += PI-angle_v3v3v3(vLr, vC, vRr);	// calculate angle between left and right vectors and add it to f
							}
							if (shape == 0) f /= 2;	// take the average
						
							// filter strength calculation from angle 0 - 1 deg = 1 - 0 multiplier
							// the angle itself is multiplied by the surfPres constant
							if (f != 0) {
						//		printf("%g ",PI-angle_v3v3v3(vUr, vC, vDr));
								f /= surfPres;
						//		printf("%g ",PI-angle_v3v3v3(vLr, vC, vRr));
								if (fallOff == 0) f = (2+floor(-f*f)+fabs(2+floor(-f*f)))/2;		// constant fall-off, calculate additional factor ( y = (2+floor(-x*x)+abs(2+floor(-x*x)))/2 )
								if (fallOff == 1) f = (1-fabs(f)+fabs(1-fabs(f)))/2;				// linear fall-off, calculate additional factor ( y = (1-abs(x)+abs(1-abs(x)))/2
								if (fallOff == 2) f = ((1-f*f)+fabs(1-f*f))/2;					// square fall-off, calculate additional factor ( y = ((1-x*x)+abs(1-x*x))/2 )
								if (fallOff == 3) f = 1-atan(f*f)/PI*2;							// ease/soft fall-off, calculate additional factor ( y = 1-atan(x*x)/PI*2 )
						//		printf("%g\n",f);
							} else f = 1;	
							if (xf != 0) vertex[idxC+0] += xf*factor *f;	// apply factor and set new center vertices
							if (yf != 0) vertex[idxC+1] += yf*factor *f;
							if (zf != 0) vertex[idxC+2] += zf*factor *f;
						}
					}
				}
			}
		}
	}
}

void getCorrectedRGBimg(unsigned char *rgb)
{
	unsigned char rgbOrig[640*480*3];
	int i, x, xGet, y, yGet;
	float depthPos, Ax,Ay,Bx,By,Cx,Cy, f,fX,fY,fS;
	float opt1,opt2,opt3, opt1o,opt2o,opt3o, opt4,opt5,opt6;

	Ax = .5; Bx = 2; Cx = 13; 
	opt1o = (Ax -Bx)*(Ax -Cx);
	opt2o = (Bx -Ax)*(Bx -Cx);
	opt3o = (Cx -Ax)*(Cx -Bx);
	memcpy(&rgbOrig, rgb, 640*480*3);
	for (y=0; y<480; y++) {
		for (x=0; x<640; x++) {
			f = depth[y*640+x];
			f = -(1/((f-1091)/355));	// convert kinect depth to meters
			// Lagrange polynom parable used for RGB offset correction, see docs for details
			// Following code is optimized, original formular looks like this:
		/*	Ay = RGBshiftX[0]; By = RGBshiftX[1]; Cy = RGBshiftX[2];
			fX = Ay /((Ax -Bx)*(Ax -Cx))*(f -Bx)*(f -Cx) +By/((Bx -Ax)*(Bx -Cx))*(f -Ax)*(f -Cx) +Cy/((Cx -Ax)*(Cx -Bx))*(f -Ax)*(f -Bx);
			Ay = RGBshiftY[0]; By = RGBshiftY[1]; Cy = RGBshiftY[2];
			fY = Ay /((Ax -Bx)*(Ax -Cx))*(f -Bx)*(f -Cx) +By/((Bx -Ax)*(Bx -Cx))*(f -Ax)*(f -Cx) +Cy/((Cx -Ax)*(Cx -Bx))*(f -Ax)*(f -Bx);
			Ay = RGBshiftS[0]; By = RGBshiftS[1]; Cy = RGBshiftS[2];
			fS = Ay /((Ax -Bx)*(Ax -Cx))*(f -Bx)*(f -Cx) +By/((Bx -Ax)*(Bx -Cx))*(f -Ax)*(f -Cx) +Cy/((Cx -Ax)*(Cx -Bx))*(f -Ax)*(f -Bx);	*/
			opt4 = (f -Bx);
			opt5 = (f -Cx);
			opt6 = (f -Ax);
			opt1 = opt4*opt5;
			opt2 = opt6*opt5;
			opt3 = opt3o *opt6*opt4;
			fX = RGBshiftX[0] /opt1o*opt1+RGBshiftX[1] /opt2o*opt2+RGBshiftX[2] /opt3;
			fY = RGBshiftY[0] /opt1o*opt1+RGBshiftY[1] /opt2o*opt2+RGBshiftY[2] /opt3;
			fS = RGBshiftS[0] /opt1o*opt1+RGBshiftS[1] /opt2o*opt2+RGBshiftS[2] /opt3;
			// calculate shifting value to align rgb to depth
			xGet = ((float)x-320) /fS +320 +fX;	
			yGet = ((float)y-240) /fS +240 +fY;
			//xGet = x; yGet = y;
			if (xGet>=0 && xGet<640 && yGet>=0 && yGet<480) {
				rgb[(y*640+x)*3+0] = rgbOrig[(yGet*640+xGet)*3+0];
				rgb[(y*640+x)*3+1] = rgbOrig[(yGet*640+xGet)*3+1];
				rgb[(y*640+x)*3+2] = rgbOrig[(yGet*640+xGet)*3+2];
			}
		}
	}
}

void savePLY(char *txt, char useFilter)
{
	int res, i, j, k, m, x, y;
	float xf, yf, zf;
	char ch;
	FILE *fout;
	
	getCorrectedRGBimg(rgb);

	fout = fopen(txt,"w");
	fprintf(fout,"ply\n");
	fprintf(fout,"format ascii 1.0\n");
	fprintf(fout,"comment Kai Kostack Kinect 3D scanner generated\n");
	// precount vertices
	for (i=0,j=0; i<640*480; i++) {
		depthPos = depth[i];
		if (depthPos>340 && depthPos<1081) j++;
	}
	fprintf(fout,"element vertex %d\n", j);
	fprintf(fout,"property float x\n");
	fprintf(fout,"property float y\n");
	fprintf(fout,"property float z\n");
	fprintf(fout,"property uchar red\n");
	fprintf(fout,"property uchar green\n");
	fprintf(fout,"property uchar blue\n");
	// precount faces
	for (y=1,j=0; y<480; y++) 
		for (x=1; x<640; x++) {
			depthPos = depth[y*640+x];
			if (depthPos>340 && depthPos<1081) {
				k = depthPos;
				depthPos = depth[(y-1)*640+(x-1)];
				if (depthPos>340 && depthPos<1081 && depthPos > k-maxSteps && depthPos < k+maxSteps) {
					k = depthPos;
					depthPos = depth[y*640+x-1];
					if (depthPos>340 && depthPos<1081 && depthPos > k-maxSteps && depthPos < k+maxSteps) {
						k = depthPos;
						depthPos = depth[(y-1)*640+x];
						if (depthPos>340 && depthPos<1081 && depthPos > k-maxSteps && depthPos < k+maxSteps) j++;
						else j++;
					} else {
						depthPos = depth[(y-1)*640+x];
						if (depthPos>340 && depthPos<1081 && depthPos > k-maxSteps && depthPos < k+maxSteps) j++;					
		}}}}
	fprintf(fout,"element face %d\n", j);
	fprintf(fout,"property list uchar int vertex_indices\n");
	fprintf(fout,"end_header\n");	
	// calculate vertices
	for (y=0,i=0,j=0; y<480; y++) 
		for (x=0; x<640; x++,i++) {
			// numbers seems to be in ranges:
			// extrema 18,1120
			// 2 rooms +floor (~13m) 1064
			// 1 room +floor (~7m) 1045
			// 6.0m 1038
			// 1.7m 875
			// 1.0m 765
			// 0.6m 456
			// 0.5m 370 minimum measureable distance
			depthPos = (int) depth[i];
			if (depthPos>340 && depthPos<1081){
				xf = (float) x;
				yf = (float) y;
				zf = (float) depth[i];
				zf = -(1/((zf-1091)/355)); // convert depth to meters, see diagrams for details... 351=0.48m, 1080=32m, 1090=355m
				xf = ((xf -320) /320) *zf *.5; // perspective correction for X displacement of 57� FOV
				yf = ((yf -240) /240) *zf *.4; // perspective correction for Y
				// store vertex coordinates
				vertex[(y*640+x)*3+0] = xf;
				vertex[(y*640+x)*3+1] = -yf;
				vertex[(y*640+x)*3+2] = -zf;
				vertIdx[i] = j;	// store indices for further processing
				j++;
			}
		}
	// apply noise filter
	// perform smoothing filter to remove noise (use iterations here to remove low frequency noise better)
		if (useFilter != 0)	{
		// (float factor, int iterations, float surfacePreserve, short radius, short shape, short fallOff)
		filterVertices(.5, 2, 0, 0, 0, 0);
		filterVertices(.5, 20, 1., 8, 1, 1);
		filterVertices(.5, 20, 1., 8, 2, 1);
		filterVertices(.5, 20, .5, 2, 1, 3);
		filterVertices(.5, 20, .5, 2, 2, 3);
//		filterVertices(.95, 50, .05, 2, 0, 3);
	}
	// save vertices to file
	for (y=0,i=0; y<480; y++) 
		for (x=0; x<640; x++,i++) {
			depthPos = (int) depth[i];
			if (depthPos>340 && depthPos<1081){
				j = (y*640+x)*3;
				if (isnan(vertex[j+0]) || isinf(vertex[j+0]) || vertex[j+0] < -100 || vertex[j+0] > 100) vertex[j+0] = 0;
				if (isnan(vertex[j+1]) || isinf(vertex[j+1]) || vertex[j+1] < -100 || vertex[j+1] > 100) vertex[j+1] = 0;
				if (isnan(vertex[j+2]) || isinf(vertex[j+2]) || vertex[j+2] < -100 || vertex[j+2] > 100) vertex[j+2] = 0;
				fprintf(fout,"%g %g %g %d %d %d\n",vertex[j+0], vertex[j+1], vertex[j+2], rgb[j+0], rgb[j+1], rgb[j+2]);
			}
		}
	// save faces
	for (y=1; y<480; y++) 
		for (x=1; x<640; x++) {
			depthPos = depth[y*640+x];
			if (depthPos>340 && depthPos<1081) {
				k = depthPos;
				depthPos = depth[(y-1)*640+(x-1)];
				if (depthPos>340 && depthPos<1081 && depthPos > k-maxSteps && depthPos < k+maxSteps) {
					k = depthPos;
					depthPos = depth[y*640+x-1];
					if (depthPos>340 && depthPos<1081 && depthPos > k-maxSteps && depthPos < k+maxSteps) {
						k = depthPos;
						depthPos = depth[(y-1)*640+x];
						if (depthPos>340 && depthPos<1081 && depthPos > k-maxSteps && depthPos < k+maxSteps) {
							fprintf(fout,"4 %d %d %d %d\n", vertIdx[(y-1)*640+(x-1)], vertIdx[y*640+x-1], vertIdx[y*640+x], vertIdx[(y-1)*640+x]);	// save a quad if possible
						}
						else fprintf(fout,"3 %d %d %d\n", vertIdx[y*640+x], vertIdx[(y-1)*640+(x-1)], vertIdx[y*640+x-1]); // in case there are not enough vertices for a quad save a triangle
					}
					else {
						depthPos = depth[(y-1)*640+x];
						if (depthPos>340 && depthPos<1081 && depthPos > k-maxSteps && depthPos < k+maxSteps)
							fprintf(fout,"3 %d %d %d\n", vertIdx[(y-1)*640+(x-1)], vertIdx[y*640+x], vertIdx[(y-1)*640+x]); // in case there are not enough vertices for a quad save a triangle
					}
				}
			}			
		}
	fclose(fout);		
}

void depthimg(uint16_t *buf, int width, int height)
{
	int i;
	float f;

	// Kai's code
	float depthOld;
	int depthOldCounter, samplesToUse;
	up=0; down=2047;
		
	pthread_mutex_lock(&gl_backbuf_mutex);
	for (i=0; i<640*480; i++) {
		int pval = t_gamma[buf[i]];
		int lb = pval & 0xff;

		// Kai's code
		// check which sample count to use depending on scan mode (with motor or just plain subsampling)
		if (qScanWithMotor) {
			samplesToUse = scanWithMotorSamples;
		}
		else samplesToUse = samples;
		// check which scan mode and do saving depth and subsampling
		if (!qScanWithMotor || (qScanWithMotor && scanWithMotorSec != scanWithMotorSecOld)) {		
			depthPos = buf[i];
			if (depthPos>340 && depthPos<1081) {
				depthOld = f = depth[i];
				depthOldCounter = maxSteps;
				if (depthKill[i] == 0) {
					depth[i] = (float) depthPos;
					depthKill[i] = 1;
				}
				else if (depthPos > f-maxSteps && depthPos < f+maxSteps) {			// only do subsampling if depths are not more different than maxSteps steps
					depth[i] = (f*(samplesToUse-1) +(float) depthPos) /samplesToUse;
					depthKill[i] = 1;
				}
				else depthKill[i]++;
				depthOldCounter = 0;
			}
			else depthKill[i]++;				// increment sample counter for killing old samples because now it's out of range
		
			if (depthKill[i] > samplesToUse) {
				depth[i] = (float) depthPos;
				depthKill[i] = 1;
			}
			// vertical gaps closing module
			if (!(depthPos>340 && depthPos<1081)) {
				if (depthOldCounter < maxSteps) {
					depth[i] = depthOld;
					depthKill[i] = 1;	
					depthOldCounter++;
				}
			}
		}

		// do depth clipping
		if (qDepthClipping) {
				f = depth[i];
				if (f > clippingFar) depth[i] = 0;
				if (f < clippingClose) depth[i] = 0;
		}
		
		// store extremes for later display
		depthPos = depth[i];
		if (depthPos != 0) {
			if (depthPos > up && depthPos<2047) up = depthPos;
			if (depthPos < down) down = depthPos;
		}

		// drawing
		if (depthPos>340 && depthPos<1081) {
			lb = 255 -(depthPos /4 -300);
			gl_depth_back[3*i+0] = lb;
			gl_depth_back[3*i+1] = lb;
			gl_depth_back[3*i+2] = lb;	
		}
		else {
			gl_depth_back[3*i+0] = 0;
			gl_depth_back[3*i+1] = 0;
			gl_depth_back[3*i+2] = 128;		
		}
		if (qRGBcalibration) {
			gl_depth_back[3*i+0] = (gl_depth_back[3*i+0]*2 + rgb[3*i+0]) /3;
			gl_depth_back[3*i+1] = (gl_depth_back[3*i+1]*2 + rgb[3*i+1]) /3;
			gl_depth_back[3*i+2] = (gl_depth_back[3*i+2]*2 + rgb[3*i+2]) /3;
		}

/*				
		switch (pval>>8) {
			case 0:
				gl_depth_back[3*i+0] = 255;
				gl_depth_back[3*i+1] = 255-lb;
				gl_depth_back[3*i+2] = 255-lb;
			break;
			case 1:
				gl_depth_back[3*i+0] = 255;
				gl_depth_back[3*i+1] = lb;
				gl_depth_back[3*i+2] = 0;
			break;
			case 2:
				gl_depth_back[3*i+0] = 255-lb;
				gl_depth_back[3*i+1] = 255;
				gl_depth_back[3*i+2] = 0;
			break;
			case 3:
				gl_depth_back[3*i+0] = 0;
				gl_depth_back[3*i+1] = 255;
				gl_depth_back[3*i+2] = lb;
			break;
			case 4:
				gl_depth_back[3*i+0] = 0;
				gl_depth_back[3*i+1] = 255-lb;
				gl_depth_back[3*i+2] = 255;
			break;
			case 5:
				gl_depth_back[3*i+0] = 0;
				gl_depth_back[3*i+1] = 0;
				gl_depth_back[3*i+2] = 255-lb;
			break;
			default:
				gl_depth_back[3*i+0] = 0;
				gl_depth_back[3*i+1] = 0;
				gl_depth_back[3*i+2] = 0;
			break;
		}
*/	}
	got_frames++;
	pthread_cond_signal(&gl_frame_cond);
	pthread_mutex_unlock(&gl_backbuf_mutex);
}

void rgbimg(uint8_t *buf, int width, int height)
{
	pthread_mutex_lock(&gl_backbuf_mutex);
	memcpy(gl_rgb_back, buf, width*height*3);
	// Kai's Code
	if (qRGBcalibration) {
		if (mCounter%15 == 0) {
			memcpy(rgb, buf, width*height*3);
			getCorrectedRGBimg(rgb);
		}
	}
	else memcpy(rgb, buf, width*height*3);
	mCounter++;
	got_frames++;
	pthread_cond_signal(&gl_frame_cond);
	pthread_mutex_unlock(&gl_backbuf_mutex);
}

#endif


int main(int argc, char **argv)
{
	// Kai's code
	int res, i, m;
	int fIdx = 1;
	char txt[256];
	FILE *fout;
		
	int die = 0;
	unsigned char ch;

	for (i=0; i<2048; i++) {	t_gamma[i] = powf(i/2048.0,3)*6*6*256;	}

	if(init_camera_device() != FREENECT_OK)
	{
			printf("Error, couldn't open the camera device.\n");
			return -1;
	}

	#if defined(PTHREAD_AND_GLUT)
		g_argc = argc;
		g_argv = argv;

		res = pthread_create(&gl_thread, NULL, gl_threadfunc, NULL);
		if (res) {
			printf("pthread_create failed\n");
			return 1;
		}
	#endif
	#if defined(WIN32)
	Sleep(3000);
	#endif


	start_camera_device();
	#if defined(PTHREAD_AND_GLUT)
	prep_iso_transfers(depthimg, rgbimg);
	#else
	prep_iso_transfers(NULL, NULL);
	#endif

		// Kai's code

		loadIniSettings(argv[0]);
		
		system("cls");
		printf("Kinect 3D Scanner v1.04                      Copyright (C) 2010-2011 Kai Kostack");
		printf("This program is free software; you can redistribute & change it under the terms\nof the GNU General Public License. See the GPL-License file for more details.\n\n");

		printf("Available keyboard commands:\n\n");
		printf("[S]  Snapshot and save it to a new .PLY file\n");
		printf("[R]  Raw snapshot and save it to a new .PLY file (Without noise filter)\n");
		printf("[T]  Toggle snapshot timer (Starts serial snapshot mode)\n\n");
		printf("[M]  Toggle motor balance\n");
		printf("     [Q]            Tilt up\n");
		printf("     [A]            Tilt down\n\n");	
		printf("[C]  Toggle RGB alignment calibration mode\n");
		printf("     [1] [2] [3]    Switch between distance levels: close, medium, far\n");
		printf("     [+] [-]        Change plane scaling at chosen level\n");
		printf("     [Cursor Keys]  Shift XY-plane at chosen level\n\n");
		printf("[D]  Toggle depth clipping\n");
		printf("     [F] [G]        Move far clipping plane\n");
		printf("     [V] [B]        Move close clipping plane\n\n");
		
		init_motor_device();
		

		sprintf(txt,"3dscan%04d.ply",fIdx);
		fout=fopen(txt,"r");
		while (fout) {
			fclose(fout);
			fIdx++;
			sprintf(txt,"3dscan%04d.ply",fIdx);
			fout=fopen(txt,"r");
		}
		
		mCounter = 0; m = 0;
		while( die == 0 ){
			
			update_isochronous_async();
		
			// Kai's code
			
			if (qUseMotor) {
				if (m%15==0) set_motor_tilt(MotorTilt);	// call only once in 15 loops otherwise the servo would not come to speed
				m++;
			}

			if (qScanWithMotor) {
				scanWithMotorSecOld = scanWithMotorSec;
				scanWithMotorSec = time (NULL);
				if (scanWithMotorSec != scanWithMotorSecOld) {
					MotorTilt -= 10;
					scanWithMotorInc++;
				}
				if (scanWithMotorInc > scanWithMotorTimeToWait){
					scanWithMotorInc = 0;
					if (scanWithMotorSampleInc > scanWithMotorSamples){ // all samples done
						qScanWithMotor = 0;
						qSaveNow = 1;
						scanWithMotorSampleInc = 0;
					}
					scanWithMotorSampleInc++;
				}
			}

			if (qUseTimer) {
				timerSecOld = timerSec;
				timerSec = time (NULL);
				if (timerSec != timerSecOld) timerInc++;
				if (timerInc > timeToWait) {
					qSaveNow = 1;
					timerInc = 0;
				}
			}
			
			if (kbhit() || chKey != 0 || qSaveNow) {
				if (kbhit()) ch = getch();
				else if (chKey != 0) ch = chKey;
				else ch = 0;
				chKey = 0;
				
				if (ch == 'q') MotorTilt += 10;
				if (ch == 'a') MotorTilt -= 10;
				if (ch == 't') qUseTimer = !qUseTimer;
				if (ch == 'm') qUseMotor = !qUseMotor;

				// RGB calibration keys
				if (ch == 'c') qRGBcalibration = !qRGBcalibration;
				if (qRGBcalibration) {
					if (ch == '1') qRGBcalibrationLevel = 0;
					if (ch == '2') qRGBcalibrationLevel = 1;
					if (ch == '3') qRGBcalibrationLevel = 2;
					if (ch == 72)	RGBshiftY[qRGBcalibrationLevel] -= 1;
					if (ch == 80)	RGBshiftY[qRGBcalibrationLevel] += 1;
					if (ch == 75)	RGBshiftX[qRGBcalibrationLevel] -= 1;
					if (ch == 77)	RGBshiftX[qRGBcalibrationLevel] += 1;
					if (ch == '+')	RGBshiftS[qRGBcalibrationLevel] += .01;
					if (ch == '-')	RGBshiftS[qRGBcalibrationLevel] -= .01;
					if (ch == 72 || ch == 80 || ch == 75 || ch == 77 || ch == '+' || ch == '-') saveIniSettings(argv[0]);
				}

				// depth clipping keys
				if (ch == 'd') qDepthClipping = !qDepthClipping;
				if (qDepthClipping) {
					if (ch == 'g') if (clippingFar<1081) clippingFar += 2;
					if (ch == 'f') if (clippingFar>340 && clippingFar > clippingClose) clippingFar -= 2;
					if (ch == 'b') if (clippingClose<1081 && clippingClose < clippingFar) clippingClose += 2;
					if (ch == 'v') if (clippingClose>340) clippingClose -= 2;
					if (ch == 'g' || ch == 'f' || ch == 'b' || ch == 'v') saveIniSettings(argv[0]);
				}

				// saving keys
				if (ch == 's' && qUseMotor) {
					//qScanWithMotor = 1;
					//ch = 0;
				}
				if (ch == 's' || ch == 'r' || qSaveNow) {
					qSaveNow = 0;
					printf("SAVING 3D SCAN...");
					sprintf(txt,"3dscan%04d.ply",fIdx);
					
					if (ch != 'r') savePLY(txt, 1);	// save with filter applied
					else savePLY(txt, 0);			// save raw data
					
					fIdx++;
					if (qUseTimer) {
						timerSecOld = timerSec;
						timerSec = time (NULL);
					}
					printf("\r                                                                               ", -(1/(((float)down-1091)/355)), -(1/(((float)up-1091)/355)));
				}
				else if (ch == 27) {
					die = 1;
				}
				else;// printf("KEYBOARD INPUT: %d\n", ch);
			}
			//printf("\rDistance range: %d - %d",down,up);
			if  (qDepthClipping) printf("\rDistance range (clipped): %.03f m - %.03f m   ",  -(1/(((float)down-1091)/355)), -(1/(((float)up-1091)/355)) );
			else                 printf("\rDistance range: %.03f m - %.03f m             ", -(1/(((float)down-1091)/355)), -(1/(((float)up-1091)/355)) );
		}
		
		close_motor_device();

		printf("DONE!\n");

	#if defined(PTHREAD_AND_GLUT)
		pthread_exit(NULL);
	#endif

	return 0;
}

